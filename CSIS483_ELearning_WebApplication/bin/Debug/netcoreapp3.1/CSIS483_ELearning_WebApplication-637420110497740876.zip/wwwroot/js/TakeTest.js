﻿
//Submit test button clicked
$(".btnSubmitTest").on('click', function () {
    $(".divTestContents p").each(function () {
        alert("hi");
    });
});