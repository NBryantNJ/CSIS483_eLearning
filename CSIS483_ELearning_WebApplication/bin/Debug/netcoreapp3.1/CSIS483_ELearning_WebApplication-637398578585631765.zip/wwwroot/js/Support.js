﻿//------------------Email send button clicked-------------------------
$(".btnSubmitData").on('click', function () {
    var allFieldsCorrect = errorCheckInputFields();

    if (allFieldsCorrect === true)
    {
        //Format Loading Style
        $(".btnSubmitData p").css("visibility", "hidden");
        $(".loadingGif").css("visibility", "visible");

        //Populate data from input sections
        var Name = "Nick";
        $.ajax({
            type: 'POST',
            url: '/home/sendSupportMail',
            data: '{name:Name}',
            contentType: 'application/json; charset=utf-8',
            dataType: 'json',
            success: function (data) {
                if (data === true) {
                    //Success output view to user
                    ajaxSuccessDataStyling();
                }
                else {
                    alert("Error: Email not sent.");
                }
            }
        });
    }
    //Else if all fields aren't filled out
    else {
        alert("Error: All fields must be filled out");
    }
});



//Error check fields
function errorCheckInputFields() {
    var allFieldsCorrect = true;

    if ($(".inputFirstName").val().length < 1) {
        allFieldsCorrect = false;
        $(".inputFirstName").css("border-color", "red");
    }
    else {
        $(".inputFirstName").css("border-color", "#ccc");
    }

    if ($(".inputLastName").val().length < 1) {
        allFieldsCorrect = false;
        $(".inputLastName").css("border-color", "red");
    }
    else {
        $(".inputLastName").css("border-color", "#ccc");
    }


    if ($(".inputEmail").val().length < 1) {
        allFieldsCorrect = false;
        $(".inputEmail").css("border-color", "red");
    }
    else {
        var pattern = /^\w+@[a-zA-Z_]+?\.[a-zA-Z]{2,3}$/; 
        if (pattern.test($(".inputEmail").val()) === true)
        {
            $(".inputEmail").css("border-color", "#ccc");
        }
        else {
            allFieldsCorrect = false;
            $(".inputEmail").css("border-color", "red");
        }

    }

    if ($(".inputSelectReason").val() === "") {
        allFieldsCorrect = false;
        $(".inputSelectReason").css("border-color", "red");
    }
    else {
        $(".inputSelectReason").css("border-color", "#ccc");
    }

    return allFieldsCorrect; 
}

//Data Sent Format
function ajaxSuccessDataStyling() {
    $(".btnSubmitData p").css("visibility", "visible");
    $(".btnSubmitData p").text("SENT");
    $(".btnSubmitData").attr('disabled', 'disabled');
    $(".btnSubmitData").css("background-color", "#4EC078")
    $(".btnSubmitData").css("opacity", "1")
    $(".btnSubmitData").css("border-style", "none")
    $(".loadingGif").css("visibility", "hidden");
    $(".emailBackgroundDimmmer").css("visibility", "visible");
    $(".emailBackgroundDimmmer").css("opacity", ".5");
    $(".emailSentPopUp").css("visibility", "visible");
    clearInputFields(); 
}


//Clear fields
function clearInputFields() {
    $(".inputFirstName").val("");
    $(".inputLastName").val(""); 
    $(".inputEmail").val(""); 
    $(".inputUsername").val(""); 
    $(".inputSelectReason").val(""); 
    $(".textAreaMoreInfo").val(""); 
}



//------------------Close out button clicked on email pop up------------------------
$(".btnCloseOut").on('click', function () {
    $(".emailBackgroundDimmmer").css("opacity", "0");
    $(".emailSentPopUp").css("opacity", "0");

    setTimeout(function () {
        $(".emailSentPopUp").css("visibility", "hidden");
        $(".emailBackgroundDimmmer").css("visibility", "hidden");
    }, 1000);
});